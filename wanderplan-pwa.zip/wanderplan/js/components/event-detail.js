// ── Views.EventDetail ────────────────────────────────────────────
Views = window.Views || {};
Views.EventDetail = (() => {
  let tripId, dayId, eventId, onSave;
  let ev = {};
  let activeTab = 'info';

  function open(_tripId, _dayId, _eventId, _onSave) {
    tripId = _tripId; dayId = _dayId; eventId = _eventId; onSave = _onSave;
    ev = eventId ? { ...DB.getEvents(tripId).find(e => e.id === eventId) } : {
      title: '', startTime: '', endTime: '', description: '',
      images: [], links: [], address: '', googleMapsUrl: '',
      lat: null, lng: null, category: 'attraction', status: 'planned', tags: []
    };
    activeTab = 'info';
    render();
    App.openModal('modal-event-detail');
  }

  function render() {
    document.getElementById('ev-detail-modal-title').textContent = eventId ? '編輯行程' : '新增行程';
    document.getElementById('ev-detail-title').value = ev.title || '';

    // Category selector
    const cats = [
      { v: 'attraction', l: '🏛️ 景點' }, { v: 'restaurant', l: '🍜 餐廳' },
      { v: 'hotel', l: '🏨 住宿' }, { v: 'shopping', l: '🛍️ 購物' },
      { v: 'activity', l: '🎯 體驗' }
    ];
    document.getElementById('ev-detail-category').innerHTML = cats.map(c =>
      `<option value="${c.v}" ${ev.category === c.v ? 'selected' : ''}>${c.l}</option>`
    ).join('');

    document.getElementById('ev-detail-start').value = ev.startTime || '';
    document.getElementById('ev-detail-end').value = ev.endTime || '';
    document.getElementById('ev-detail-desc').value = ev.description || '';
    document.getElementById('ev-detail-addr').value = ev.address || '';

    renderPhotos();
    renderLinks();
    renderMap();
    switchTab('info');
    bindTabEvents();
    bindSave();
    bindPhotoAdd();
    bindLinkAdd();
    bindMapBtn();
  }

  function switchTab(tab) {
    activeTab = tab;
    document.querySelectorAll('.ev-detail-tab').forEach(el => el.classList.toggle('active', el.dataset.tab === tab));
    document.querySelectorAll('.ev-detail-panel').forEach(el => el.classList.toggle('hidden', el.dataset.panel !== tab));
  }

  function bindTabEvents() {
    document.querySelectorAll('.ev-detail-tab').forEach(el => {
      el.onclick = () => switchTab(el.dataset.tab);
    });
  }

  function renderPhotos() {
    const strip = document.getElementById('ev-photos-strip');
    strip.innerHTML = (ev.images || []).map((img, i) => `
      <div class="photo-thumb-ev" style="background-image:url('${img}')">
        <div class="photo-del" data-idx="${i}">×</div>
      </div>`).join('') +
      `<div class="photo-add-btn" id="ev-photo-add-btn">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M9 3v12M3 9h12" stroke="#C4A882" stroke-width="1.8" stroke-linecap="round"/></svg>
        <span>新增照片</span>
      </div>`;
    strip.querySelectorAll('.photo-del').forEach(el => {
      el.onclick = () => {
        ev.images.splice(+el.dataset.idx, 1);
        renderPhotos();
      };
    });
  }

  function bindPhotoAdd() {
    const strip = document.getElementById('ev-photos-strip');
    strip.onclick = async e => {
      if (!e.target.closest('#ev-photo-add-btn')) return;
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*'; inp.multiple = true;
      inp.onchange = async () => {
        for (const f of inp.files) {
          const url = await App.readFileAsDataURL(f);
          ev.images = ev.images || [];
          ev.images.push(url);
        }
        renderPhotos();
      };
      inp.click();
    };
  }

  function renderLinks() {
    const wrap = document.getElementById('ev-links-wrap');
    wrap.innerHTML = (ev.links || []).map((l, i) => `
      <div class="link-item">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5.5 3H3a1 1 0 00-1 1v7a1 1 0 001 1h7a1 1 0 001-1V8.5" stroke="#4A8C7A" stroke-width="1.2" stroke-linecap="round"/><path d="M8 2h4v4M12 2L7 7" stroke="#4A8C7A" stroke-width="1.2" stroke-linecap="round"/></svg>
        <a class="link-item-url" href="${l.url}" target="_blank">${l.label || l.url}</a>
        <span class="link-del" data-idx="${i}">×</span>
      </div>`).join('');
    wrap.querySelectorAll('.link-del').forEach(el => {
      el.onclick = () => { ev.links.splice(+el.dataset.idx, 1); renderLinks(); };
    });
  }

  function bindLinkAdd() {
    document.getElementById('ev-link-add-btn').onclick = () => {
      const urlInput = document.getElementById('ev-link-url');
      const lblInput = document.getElementById('ev-link-label');
      const url = urlInput.value.trim();
      if (!url) { App.toast('請輸入連結網址'); return; }
      ev.links = ev.links || [];
      ev.links.push({ url, label: lblInput.value.trim() || url });
      urlInput.value = ''; lblInput.value = '';
      renderLinks();
    };
  }

  function renderMap() {
    const wrap = document.getElementById('ev-mini-map');
    wrap.innerHTML = ev.address || ev.googleMapsUrl
      ? `<div style="font-size:13px;color:var(--ink2);padding:0 12px">${ev.address || '已設定位置'}</div>
         <div class="mini-map-label">Google Maps ↗</div>`
      : `<svg width="32" height="32" viewBox="0 0 32 32" fill="none"><path d="M16 4a8 8 0 018 8c0 7-8 16-8 16S8 19 8 12a8 8 0 018-8z" stroke="#C4A882" stroke-width="1.5"/><circle cx="16" cy="12" r="3" stroke="#C4A882" stroke-width="1.5"/></svg>`;
  }

  function bindMapBtn() {
    document.getElementById('ev-map-open-btn').onclick = () => {
      const addr = document.getElementById('ev-detail-addr').value.trim();
      if (!addr) { App.toast('請先輸入地址'); return; }
      ev.address = addr;
      window.open(`https://maps.google.com/?q=${encodeURIComponent(addr)}`, '_blank');
    };
    document.getElementById('ev-mini-map').onclick = () => {
      const url = ev.googleMapsUrl || (ev.address ? `https://maps.google.com/?q=${encodeURIComponent(ev.address)}` : null);
      if (url) window.open(url, '_blank');
    };
  }

  function bindSave() {
    document.getElementById('ev-detail-save').onclick = save;
  }

  function save() {
    ev.title       = document.getElementById('ev-detail-title').value.trim();
    ev.category    = document.getElementById('ev-detail-category').value;
    ev.startTime   = document.getElementById('ev-detail-start').value;
    ev.endTime     = document.getElementById('ev-detail-end').value;
    ev.description = document.getElementById('ev-detail-desc').value.trim();
    ev.address     = document.getElementById('ev-detail-addr').value.trim();
    if (ev.address) ev.googleMapsUrl = `https://maps.google.com/?q=${encodeURIComponent(ev.address)}`;

    if (!ev.title) { App.toast('請輸入行程名稱'); return; }

    // Conflict check
    if (ev.startTime && ev.endTime) {
      const conflicts = DB.checkConflict(tripId, dayId, ev.startTime, ev.endTime, eventId);
      if (conflicts.length) {
        if (!confirm(`時間與「${conflicts[0].title}」重疊，仍要儲存嗎？`)) return;
      }
    }

    if (eventId) {
      DB.updateEvent(tripId, eventId, ev);
    } else {
      DB.createEvent(tripId, dayId, ev);
    }

    App.closeModal('modal-event-detail');
    App.toast(eventId ? '行程已更新 ✓' : '行程已新增 ✓');
    onSave && onSave();
  }

  return { open };
})();


// ── Views.TransportPicker ────────────────────────────────────────
Views.TransportPicker = (() => {
  let tripId, fromEventId, onSave;
  let selectedMode = null;
  let tr = {};

  const MODES = [
    { id: 'walk',  label: '步行',  cls: 'walk',  color: 'var(--brown)' },
    { id: 'rail',  label: '電車',  cls: 'rail',  color: 'var(--teal)' },
    { id: 'bus',   label: '巴士',  cls: 'bus',   color: 'var(--sky)' },
    { id: 'air',   label: '飛機',  cls: 'air',   color: 'var(--rose)' },
    { id: 'ferry', label: '渡輪',  cls: 'ferry', color: 'var(--navy)' },
    { id: 'taxi',  label: '計程車', cls: 'taxi', color: 'var(--green)' },
  ];

  const MODE_ICONS = {
    walk:  `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><circle cx="11" cy="11" r="8" stroke="currentColor" stroke-width="1.4"/><path d="M11 7.5v4.5M11 15v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
    rail:  `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect x="4" y="7" width="14" height="9" rx="2.5" stroke="currentColor" stroke-width="1.4"/><path d="M8 7V6a2 2 0 012-2h2a2 2 0 012 2v1" stroke="currentColor" stroke-width="1.4"/><circle cx="7.5" cy="14" r="1.2" fill="currentColor"/><circle cx="14.5" cy="14" r="1.2" fill="currentColor"/><path d="M4 11h14" stroke="currentColor" stroke-width="1" opacity=".4"/></svg>`,
    bus:   `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect x="3" y="7.5" width="16" height="8" rx="2" stroke="currentColor" stroke-width="1.4"/><path d="M7 7.5V6.5a1.5 1.5 0 011.5-1.5h5A1.5 1.5 0 0115 6.5v1" stroke="currentColor" stroke-width="1.4"/><circle cx="6.5" cy="14.5" r="1.2" fill="currentColor"/><circle cx="15.5" cy="14.5" r="1.2" fill="currentColor"/><path d="M17 10.5h1.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`,
    air:   `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M4 16l7-10 7 10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M2.5 16h17" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><rect x="7.5" y="16" width="7" height="3.5" rx="1" stroke="currentColor" stroke-width="1.2"/></svg>`,
    ferry: `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M3.5 14c0-2.5 2-5 5-5h5c3 0 5 2.5 5 5v1h-15v-1z" stroke="currentColor" stroke-width="1.4"/><path d="M8 9V6.5M14 9V6.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M11 3.5V6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M3 18.5c1.5-.5 3.5-.5 5 0s3.5.5 5 0 3.5-.5 5 0" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`,
    taxi:  `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect x="2.5" y="9" width="17" height="8" rx="2.5" stroke="currentColor" stroke-width="1.4"/><path d="M7 9V8a1.5 1.5 0 011.5-1.5h5A1.5 1.5 0 0115 8v1" stroke="currentColor" stroke-width="1.4"/><circle cx="6" cy="16" r="1.5" fill="currentColor"/><circle cx="16" cy="16" r="1.5" fill="currentColor"/><path d="M8 6H7M6 6l1-2.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`,
  };

  function open(_tripId, _fromEventId, _onSave) {
    tripId = _tripId; fromEventId = _fromEventId; onSave = _onSave;
    const existing = DB.getTransport(tripId, fromEventId);
    tr = existing ? { ...existing } : { fromEventId, mode: null, durationMin: '', cost: '', currency: 'JPY', ticketUrl: '', note: '' };
    selectedMode = tr.mode || null;

    render();
    App.openModal('modal-transport');
  }

  function render() {
    // Find event names
    const events = DB.getEvents(tripId);
    const fromEv = events.find(e => e.id === fromEventId);
    const evList = DB.getEventsByDay(tripId, fromEv?.dayId);
    const fromIdx = evList.findIndex(e => e.id === fromEventId);
    const toEv = evList[fromIdx + 1];
    document.getElementById('tr-route-label').textContent =
      `${fromEv?.title || '出發'} → ${toEv?.title || '目的地'}`;

    renderModeGrid();
    renderDetail();
    bindSave();
    bindMapsBtn();
  }

  function renderModeGrid() {
    const grid = document.getElementById('tr-mode-grid');
    grid.innerHTML = MODES.map(m => `
      <button class="tm-btn ${m.cls} ${selectedMode === m.id ? 'active' : ''}" data-mode="${m.id}">
        <div class="tm-icon" style="background:${selectedMode === m.id ? getBg(m.cls) : 'var(--cream2)'}">
          <span style="color:${selectedMode === m.id ? getColor(m.cls) : 'var(--ink3)'}">${MODE_ICONS[m.id]}</span>
        </div>
        <span class="tm-label" style="color:${selectedMode === m.id ? getColor(m.cls) : 'var(--ink2)'}">${m.label}</span>
      </button>`).join('');
    grid.querySelectorAll('.tm-btn').forEach(el => {
      el.onclick = () => {
        selectedMode = el.dataset.mode;
        tr.mode = selectedMode;
        renderModeGrid();
        renderDetail();
      };
    });
  }

  function getBg(cls) {
    return { walk:'var(--amber-light)', rail:'var(--teal-light)', bus:'var(--sky-light)', air:'var(--rose-light)', ferry:'var(--navy-light)', taxi:'var(--green-light)' }[cls] || 'var(--cream2)';
  }
  function getColor(cls) {
    return { walk:'var(--brown)', rail:'var(--teal)', bus:'var(--sky)', air:'var(--rose)', ferry:'var(--navy)', taxi:'var(--green)' }[cls] || 'var(--ink2)';
  }

  function renderDetail() {
    const box = document.getElementById('tr-detail-box');
    if (!selectedMode) { box.style.display = 'none'; return; }
    box.style.display = 'block';
    box.className = `transport-detail-box ${selectedMode}`;
    const m = MODES.find(x => x.id === selectedMode);
    box.innerHTML = `
      <div class="tr-detail-title" style="color:${getColor(selectedMode)}">${m.label} — 詳細資訊</div>
      <div class="tr-fields">
        <div class="tr-field">
          <div class="tr-field-label">時間（分鐘）</div>
          <input id="tr-dur" type="number" min="1" placeholder="例：45" value="${tr.durationMin || ''}">
        </div>
        <div class="tr-field">
          <div class="tr-field-label">票價 / 費用</div>
          <input id="tr-cost" type="number" min="0" placeholder="例：230" value="${tr.cost || ''}">
        </div>
      </div>
      <div class="tr-field" style="margin-top:10px">
        <div class="tr-field-label">票務連結（KKday、Klook…）</div>
        <input id="tr-ticket" type="url" placeholder="https://…" value="${tr.ticketUrl || ''}" style="background:rgba(255,255,255,.7);border:1px solid rgba(0,0,0,.08);border-radius:var(--r-sm);padding:7px 10px;font-size:13px;color:var(--ink);width:100%">
      </div>
      <div class="tr-field" style="margin-top:10px">
        <div class="tr-field-label">備忘</div>
        <input id="tr-note" type="text" placeholder="例：乘 JR 山手線 → 渋谷方向" value="${tr.note || ''}" style="background:rgba(255,255,255,.7);border:1px solid rgba(0,0,0,.08);border-radius:var(--r-sm);padding:7px 10px;font-size:13px;color:var(--ink);width:100%">
      </div>
      <button class="tr-maps-link" id="tr-maps-btn">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1.5a4 4 0 014 4c0 3.5-4 7-4 7S3 9 3 5.5a4 4 0 014-4z" stroke="currentColor" stroke-width="1.2"/><circle cx="7" cy="5.5" r="1.5" stroke="currentColor" stroke-width="1.2"/></svg>
        在 Google Maps 查看路線
      </button>`;
    bindMapsBtn();
  }

  function bindMapsBtn() {
    const btn = document.getElementById('tr-maps-btn');
    if (!btn) return;
    btn.onclick = () => {
      const events = DB.getEvents(tripId);
      const fromEv = events.find(e => e.id === fromEventId);
      const evList = DB.getEventsByDay(tripId, fromEv?.dayId);
      const fromIdx = evList.findIndex(e => e.id === fromEventId);
      const toEv = evList[fromIdx + 1];
      if (!fromEv?.address || !toEv?.address) {
        App.toast('請先設定出發 / 目的地地址');
        return;
      }
      const modeMap = { walk: 'walking', rail: 'transit', bus: 'transit', air: 'flying', ferry: 'transit', taxi: 'driving' };
      const gMode = modeMap[selectedMode] || 'driving';
      window.open(`https://maps.google.com/maps?saddr=${encodeURIComponent(fromEv.address)}&daddr=${encodeURIComponent(toEv.address)}&dirflg=${gMode === 'transit' ? 'r' : gMode === 'walking' ? 'w' : 'd'}`, '_blank');
    };
  }

  function bindSave() {
    document.getElementById('tr-save-btn').onclick = save;
    document.getElementById('tr-delete-btn').onclick = () => {
      DB.deleteTransport(tripId, fromEventId);
      App.closeModal('modal-transport');
      App.toast('交通資訊已刪除');
      onSave && onSave();
    };
  }

  function save() {
    if (!selectedMode) { App.toast('請選擇交通方式'); return; }
    const dur = document.getElementById('tr-dur')?.value;
    const cost = document.getElementById('tr-cost')?.value;
    const ticket = document.getElementById('tr-ticket')?.value;
    const note = document.getElementById('tr-note')?.value;

    DB.upsertTransport(tripId, {
      fromEventId,
      mode: selectedMode,
      durationMin: dur ? +dur : null,
      cost: cost ? +cost : null,
      currency: 'JPY',
      ticketUrl: ticket || '',
      note: note || ''
    });
    App.closeModal('modal-transport');
    App.toast('交通設定已儲存 ✓');
    onSave && onSave();
  }

  return { open };
})();
