// ── WanderPlan · App Shell ───────────────────────────────────────
'use strict';

const App = (() => {
  let currentScreen = 'recommend';
  let history = [];

  // ── Toast ────────────────────────────────────────────────────
  function toast(msg, duration = 2400) {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), duration);
  }

  // ── Modal Sheet ──────────────────────────────────────────────
  const overlays = {};
  function openModal(id) {
    const o = document.getElementById(id);
    if (!o) return;
    o.classList.add('show');
    overlays[id] = true;
  }
  function closeModal(id) {
    const o = document.getElementById(id);
    if (!o) return;
    o.classList.remove('show');
    delete overlays[id];
  }
  function closeAllModals() {
    document.querySelectorAll('.modal-overlay.show').forEach(o => o.classList.remove('show'));
  }

  // ── Screen Router ────────────────────────────────────────────
  const screens = ['recommend', 'trips', 'add-plan', 'editor', 'profile'];

  function navigate(screenId, params = {}, pushHistory = true) {
    const prev = document.querySelector('.screen.active');
    const next = document.getElementById(`screen-${screenId}`);
    if (!next) return;
    if (prev && prev !== next) {
      prev.classList.add('slide-left');
      setTimeout(() => prev.classList.remove('active', 'slide-left'), 220);
    }
    next.classList.add('active');
    if (pushHistory && currentScreen !== screenId) history.push({ screen: currentScreen, params: {} });
    currentScreen = screenId;
    updateNav(screenId);
    // Fire screen init
    if (screenId === 'recommend')   Views.Recommend.init(params);
    if (screenId === 'trips')       Views.Trips.init(params);
    if (screenId === 'add-plan')    Views.AddPlan.init(params);
    if (screenId === 'editor')      Views.Editor.init(params);
    if (screenId === 'profile')     Views.Profile.init(params);
  }

  function back() {
    if (history.length === 0) return;
    const prev = history.pop();
    navigate(prev.screen, prev.params, false);
  }

  function updateNav(screenId) {
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.screen === screenId);
    });
  }

  // ── Image helpers ────────────────────────────────────────────
  function readFileAsDataURL(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(file);
    });
  }

  function categoryLabel(cat) {
    return { attraction: '景點', restaurant: '餐廳', hotel: '住宿', shopping: '購物', activity: '體驗', transport: '交通' }[cat] || cat;
  }
  function transportLabel(mode) {
    return { walk: '步行', rail: '電車', bus: '巴士', air: '飛機', ferry: '渡輪', taxi: '計程車' }[mode] || '交通';
  }
  function transportClass(mode) {
    return { walk: 'tb-walk', rail: 'tb-rail', bus: 'tb-bus', air: 'tb-air', ferry: 'tb-ferry', taxi: 'tb-taxi' }[mode] || 'tb-unset';
  }
  function categoryClass(cat) {
    return { attraction: 'cat-attraction', restaurant: 'cat-restaurant', hotel: 'cat-hotel', shopping: 'cat-shopping', activity: 'cat-activity' }[cat] || '';
  }

  // ── SVG icons ────────────────────────────────────────────────
  const Icons = {
    back: `<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M11 3.5L5.5 9l5.5 5.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    clock: `<svg width="10" height="10" viewBox="0 0 10 10" fill="none"><circle cx="5" cy="5" r="4" stroke="currentColor" stroke-width="1.1"/><path d="M5 2.8V5l1.2 1.2" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>`,
    pin: `<svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M5 1a3 3 0 013 3c0 2.5-3 6-3 6S2 6.5 2 4a3 3 0 013-3z" stroke="currentColor" stroke-width="1.1"/><circle cx="5" cy="4" r="1" fill="currentColor"/></svg>`,
    plus: `<svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M6.5 1.5v10M1.5 6.5h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`,
    arrow: `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 2.5l4 4.5-4 4.5" stroke="#9E8270" stroke-width="1.4" stroke-linecap="round"/></svg>`,
    link: `<svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M4 2H2a1 1 0 00-1 1v5a1 1 0 001 1h5a1 1 0 001-1V6" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/><path d="M6 1h3v3M9 1L5 5" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>`,
  };

  // ── Boot ─────────────────────────────────────────────────────
  function init() {
    // Nav click
    document.querySelectorAll('.nav-item').forEach(el => {
      el.addEventListener('click', () => {
        const s = el.dataset.screen;
        if (s === 'add-plan') {
          openModal('modal-add-plan');
          return;
        }
        navigate(s);
      });
    });

    // Close modals on overlay click
    document.querySelectorAll('.modal-overlay').forEach(el => {
      el.addEventListener('click', e => {
        if (e.target === el) closeModal(el.id);
      });
    });

    // Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    navigate('recommend', {}, false);
  }

  return { navigate, back, toast, openModal, closeModal, closeAllModals, readFileAsDataURL, categoryLabel, transportLabel, transportClass, categoryClass, Icons };
})();

window.App = App;
document.addEventListener('DOMContentLoaded', () => App.init());
