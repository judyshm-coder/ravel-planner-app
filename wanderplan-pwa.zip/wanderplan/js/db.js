// ── WanderPlan DB Layer ──────────────────────────────────────────
// Normalised localStorage schema:
//   meta:index          → TripPlan[] (summaries)
//   tp:{id}             → TripPlan (full)
//   tp:{id}:days        → DayPlan[]
//   tp:{id}:events      → Event[]
//   tp:{id}:transports  → Transport[]

const DB = (() => {
  const PREFIX = 'wp_';
  const get = k => { try { return JSON.parse(localStorage.getItem(PREFIX + k)); } catch { return null; } };
  const set = (k, v) => { try { localStorage.setItem(PREFIX + k, JSON.stringify(v)); return true; } catch { return false; } };
  const del = k => localStorage.removeItem(PREFIX + k);

  // ── Helpers ──────────────────────────────────────────────────
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const now = () => new Date().toISOString();

  // ── Index (trip list) ────────────────────────────────────────
  function getIndex() { return get('meta:index') || []; }
  function saveIndex(idx) { return set('meta:index', idx); }
  function addToIndex(summary) {
    const idx = getIndex();
    idx.unshift(summary);
    saveIndex(idx);
  }
  function updateIndex(id, patch) {
    const idx = getIndex().map(t => t.id === id ? { ...t, ...patch } : t);
    saveIndex(idx);
  }
  function removeFromIndex(id) { saveIndex(getIndex().filter(t => t.id !== id)); }

  // ── TripPlan ─────────────────────────────────────────────────
  function createTrip({ name, startDate, endDate, destinations = [], coverImage = null }) {
    const id = uid();
    const trip = { id, name, startDate, endDate, destinations, coverImage, createdAt: now(), updatedAt: now(), calendarSyncId: null };
    set(`tp:${id}`, trip);
    // Scaffold DayPlan array
    const days = buildDayPlans(id, startDate, endDate);
    set(`tp:${id}:days`, days);
    set(`tp:${id}:events`, []);
    set(`tp:${id}:transports`, []);
    addToIndex({ id, name, startDate, endDate, destinations, coverImage, dayCount: days.length, eventCount: 0 });
    return trip;
  }

  function buildDayPlans(tripId, startDate, endDate) {
    const days = [];
    let cur = new Date(startDate);
    const end = new Date(endDate);
    let i = 1;
    while (cur <= end) {
      days.push({ id: uid(), tripId, date: cur.toISOString().slice(0, 10), dayNumber: i++, note: '' });
      cur.setDate(cur.getDate() + 1);
    }
    return days;
  }

  function getTrip(id) { return get(`tp:${id}`); }
  function updateTrip(id, patch) {
    const trip = { ...getTrip(id), ...patch, updatedAt: now() };
    set(`tp:${id}`, trip);
    updateIndex(id, { name: trip.name, startDate: trip.startDate, endDate: trip.endDate, destinations: trip.destinations, coverImage: trip.coverImage });
    return trip;
  }
  function deleteTrip(id) {
    del(`tp:${id}`); del(`tp:${id}:days`); del(`tp:${id}:events`); del(`tp:${id}:transports`);
    removeFromIndex(id);
  }

  // ── DayPlan ──────────────────────────────────────────────────
  function getDays(tripId) { return get(`tp:${tripId}:days`) || []; }
  function updateDayNote(tripId, dayId, note) {
    const days = getDays(tripId).map(d => d.id === dayId ? { ...d, note } : d);
    set(`tp:${tripId}:days`, days);
  }

  // ── Events ───────────────────────────────────────────────────
  function getEvents(tripId) { return get(`tp:${tripId}:events`) || []; }
  function getEventsByDay(tripId, dayId) {
    return getEvents(tripId).filter(e => e.dayId === dayId).sort((a, b) => {
      if (a.startTime && b.startTime) return a.startTime.localeCompare(b.startTime);
      return a.sortOrder - b.sortOrder;
    });
  }
  function createEvent(tripId, dayId, data) {
    const events = getEvents(tripId);
    const dayEvents = events.filter(e => e.dayId === dayId);
    const ev = {
      id: uid(), tripId, dayId, createdAt: now(),
      title: '', startTime: '', endTime: '', description: '',
      images: [], links: [], address: '', googleMapsUrl: '', lat: null, lng: null,
      category: 'attraction', status: 'planned', tags: [], sortOrder: dayEvents.length,
      ...data
    };
    events.push(ev);
    set(`tp:${tripId}:events`, events);
    // Update cover from first image if trip has none
    syncTripCover(tripId, ev);
    refreshIndexEventCount(tripId, events);
    return ev;
  }
  function updateEvent(tripId, eventId, patch) {
    const events = getEvents(tripId).map(e => e.id === eventId ? { ...e, ...patch } : e);
    set(`tp:${tripId}:events`, events);
    const updated = events.find(e => e.id === eventId);
    syncTripCover(tripId, updated);
    refreshIndexEventCount(tripId, events);
    return updated;
  }
  function deleteEvent(tripId, eventId) {
    const events = getEvents(tripId).filter(e => e.id !== eventId);
    set(`tp:${tripId}:events`, events);
    // Also remove transports referencing this event
    const transports = getTransports(tripId).filter(t => t.fromEventId !== eventId && t.toEventId !== eventId);
    set(`tp:${tripId}:transports`, transports);
    refreshIndexEventCount(tripId, events);
  }
  function reorderEvents(tripId, dayId, orderedIds) {
    const events = getEvents(tripId).map(e => {
      if (e.dayId !== dayId) return e;
      const idx = orderedIds.indexOf(e.id);
      return idx === -1 ? e : { ...e, sortOrder: idx };
    });
    set(`tp:${tripId}:events`, events);
  }

  function syncTripCover(tripId, ev) {
    const trip = getTrip(tripId);
    if (!trip.coverImage && ev && ev.images && ev.images.length > 0) {
      updateTrip(tripId, { coverImage: ev.images[0] });
    }
  }
  function refreshIndexEventCount(tripId, events) {
    updateIndex(tripId, { eventCount: events.length });
  }

  // Conflict detection
  function checkConflict(tripId, dayId, startTime, endTime, excludeId = null) {
    return getEventsByDay(tripId, dayId).filter(e => {
      if (e.id === excludeId || !e.startTime || !e.endTime || !startTime || !endTime) return false;
      return e.startTime < endTime && e.endTime > startTime;
    });
  }

  // ── Transports ───────────────────────────────────────────────
  function getTransports(tripId) { return get(`tp:${tripId}:transports`) || []; }
  function getTransport(tripId, fromEventId) {
    return getTransports(tripId).find(t => t.fromEventId === fromEventId) || null;
  }
  function upsertTransport(tripId, data) {
    let transports = getTransports(tripId);
    const existing = transports.findIndex(t => t.fromEventId === data.fromEventId);
    const tr = { id: uid(), durationMin: 0, distanceKm: null, ticketUrl: '', ticketInfo: '', cost: null, currency: 'JPY', bookingStatus: 'none', ...data };
    if (existing >= 0) transports[existing] = { ...transports[existing], ...data };
    else transports.push(tr);
    set(`tp:${tripId}:transports`, transports);
    return tr;
  }
  function deleteTransport(tripId, fromEventId) {
    set(`tp:${tripId}:transports`, getTransports(tripId).filter(t => t.fromEventId !== fromEventId));
  }

  // ── Export / Import ──────────────────────────────────────────
  function exportTrip(tripId) {
    return {
      version: '1.0',
      exportedAt: now(),
      trip: getTrip(tripId),
      days: getDays(tripId),
      events: getEvents(tripId),
      transports: getTransports(tripId)
    };
  }
  function exportAll() {
    return { version: '1.0', exportedAt: now(), trips: getIndex().map(t => exportTrip(t.id)) };
  }
  function importTrip(data) {
    if (!data.trip) throw new Error('Invalid format');
    const { trip, days, events, transports } = data;
    // Assign new id to avoid collision
    const newId = uid();
    const idMap = { [trip.id]: newId };
    const remap = id => idMap[id] || id;
    const newTrip = { ...trip, id: newId, name: trip.name + ' (匯入)', createdAt: now(), updatedAt: now() };
    set(`tp:${newId}`, newTrip);
    const newDays = (days || []).map(d => { const nd = { ...d, id: uid(), tripId: newId }; idMap[d.id] = nd.id; return nd; });
    set(`tp:${newId}:days`, newDays);
    const newEvents = (events || []).map(e => { const ne = { ...e, id: uid(), tripId: newId, dayId: remap(e.dayId) }; idMap[e.id] = ne.id; return ne; });
    set(`tp:${newId}:events`, newEvents);
    const newTransports = (transports || []).map(t => ({ ...t, id: uid(), tripId: newId, fromEventId: remap(t.fromEventId), toEventId: remap(t.toEventId) }));
    set(`tp:${newId}:transports`, newTransports);
    addToIndex({ id: newId, name: newTrip.name, startDate: newTrip.startDate, endDate: newTrip.endDate, destinations: newTrip.destinations, coverImage: newTrip.coverImage, dayCount: newDays.length, eventCount: newEvents.length });
    return newTrip;
  }

  // ── ICS / Calendar Export ────────────────────────────────────
  function generateICS(tripId) {
    const events = getEvents(tripId);
    const trip = getTrip(tripId);
    const fmtDT = (date, time) => {
      const d = date.replace(/-/g, '');
      if (!time) return `${d}`;
      const t = time.replace(':', '') + '00';
      return `${d}T${t}00`;
    };
    const lines = [
      'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//WanderPlan//TW',
      `X-WR-CALNAME:${trip.name}`, 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH'
    ];
    events.forEach(ev => {
      const day = (getDays(tripId).find(d => d.id === ev.dayId) || {}).date || trip.startDate;
      lines.push('BEGIN:VEVENT');
      lines.push(`UID:${ev.id}@wanderplan`);
      lines.push(`SUMMARY:${ev.title || '（未命名行程）'}`);
      lines.push(`DTSTART:${fmtDT(day, ev.startTime)}`);
      lines.push(`DTEND:${fmtDT(day, ev.endTime || ev.startTime)}`);
      if (ev.description) lines.push(`DESCRIPTION:${ev.description.replace(/\n/g, '\\n')}`);
      if (ev.address) lines.push(`LOCATION:${ev.address}`);
      lines.push('END:VEVENT');
    });
    lines.push('END:VCALENDAR');
    return lines.join('\r\n');
  }

  return {
    uid, now,
    getIndex, createTrip, getTrip, updateTrip, deleteTrip,
    getDays, updateDayNote,
    getEvents, getEventsByDay, createEvent, updateEvent, deleteEvent, reorderEvents, checkConflict,
    getTransports, getTransport, upsertTransport, deleteTransport,
    exportTrip, exportAll, importTrip, generateICS
  };
})();

window.DB = DB;
