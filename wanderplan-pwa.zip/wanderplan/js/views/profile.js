// ── Views.Profile ────────────────────────────────────────────────
Views = window.Views || {};
Views.Profile = (() => {
  function init() { render(); }

  function render() {
    // Calendar sync toggle
    const syncToggle = document.getElementById('cal-sync-toggle');
    const synced = localStorage.getItem('wp_cal_sync') === '1';
    syncToggle.classList.toggle('on', synced);
    syncToggle.onclick = () => {
      const next = !syncToggle.classList.contains('on');
      syncToggle.classList.toggle('on', next);
      localStorage.setItem('wp_cal_sync', next ? '1' : '0');
      App.toast(next ? 'Google Calendar 同步已開啟' : '同步已關閉');
    };

    // Export all
    document.getElementById('profile-export-all').onclick = exportAll;

    // Import
    document.getElementById('profile-import-btn').onclick = () => {
      document.getElementById('profile-import-input').click();
    };
    document.getElementById('profile-import-input').onchange = importData;

    // Pref countries
    document.getElementById('profile-pref-countries').onclick = () => {
      App.toast('偏好設定功能即將推出');
    };
    document.getElementById('profile-pref-style').onclick = () => {
      App.toast('旅遊風格設定即將推出');
    };
    document.getElementById('profile-pref-sources').onclick = () => {
      App.toast('部落格來源設定即將推出');
    };
  }

  function exportAll() {
    const data = DB.exportAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wanderplan-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    App.toast('全部計畫已備份 ✓');
  }

  function importData(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (data.trips && Array.isArray(data.trips)) {
          data.trips.forEach(t => DB.importTrip(t));
          App.toast(`已匯入 ${data.trips.length} 個計畫`);
        } else if (data.trip) {
          DB.importTrip(data);
          App.toast('計畫匯入成功');
        } else {
          App.toast('格式不支援');
        }
        Views.Trips.render();
      } catch {
        App.toast('匯入失敗，請確認檔案格式');
      }
      e.target.value = '';
    };
    reader.readAsText(file);
  }

  return { init };
})();
