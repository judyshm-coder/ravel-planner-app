// ── Views.Recommend ──────────────────────────────────────────────
const COUNTRIES = [
  { code: 'JP', flag: '🇯🇵', name: '日本' },
  { code: 'KR', flag: '🇰🇷', name: '韓國' },
  { code: 'TH', flag: '🇹🇭', name: '泰國' },
  { code: 'IT', flag: '🇮🇹', name: '義大利' },
  { code: 'FR', flag: '🇫🇷', name: '法國' },
  { code: 'GB', flag: '🇬🇧', name: '英國' },
  { code: 'US', flag: '🇺🇸', name: '美國' },
  { code: 'VN', flag: '🇻🇳', name: '越南' },
  { code: 'SG', flag: '🇸🇬', name: '新加坡' },
];
window.COUNTRIES = COUNTRIES;

const SAMPLE_ARTICLES = {
  JP: [
    { title: '大阪春季必去！道頓堀夜景完整攻略', source: 'MATCHA · 2025.03', tags: ['大阪','夜景','美食'], color: 'linear-gradient(135deg,#D4956A,#8C5E3A)', url: 'https://matcha-jp.com' },
    { title: '京都嵐山超私房5條散步路線', source: '痞客邦 · 2025.02', tags: ['京都','散步','嵐山'], color: 'linear-gradient(135deg,#A8C4B4,#5C8870)', url: 'https://www.pixnet.net' },
    { title: '東京 2025 最新開幕景點與主題樂園', source: 'Travel.tw · 2025.03', tags: ['東京','新開幕'], color: 'linear-gradient(135deg,#C4A0B8,#7A5870)', url: '#' },
    { title: '北海道溫泉旅館完全指南：絕景 × 美食', source: '旅行酒吧 · 2025.01', tags: ['北海道','溫泉'], color: 'linear-gradient(135deg,#A0B4C8,#5C7888)', url: '#' },
    { title: '奈良一日遊：鹿、神社、柿葉壽司', source: 'KLOOK Blog · 2025.02', tags: ['奈良','一日遊'], color: 'linear-gradient(135deg,#C4B888,#887840)', url: '#' },
  ],
  KR: [
    { title: '首爾聖水洞咖啡地圖：2025 最新整理', source: 'IG Travel · 2025.03', tags: ['首爾','咖啡','聖水洞'], color: 'linear-gradient(135deg,#C8A8B8,#886878)', url: '#' },
    { title: '釜山海雲台、甘川洞文化村一日路線', source: '旅行分享家 · 2025.02', tags: ['釜山','文化村'], color: 'linear-gradient(135deg,#90B0C8,#405870)', url: '#' },
    { title: '濟州島自駕 3 天 2 夜完整行程規劃', source: 'Travel.tw · 2025.01', tags: ['濟州','自駕'], color: 'linear-gradient(135deg,#A8C0A0,#608060)', url: '#' },
  ],
  TH: [
    { title: '清邁古城寺廟地圖：30 間不能錯過', source: 'BK Magazine · 2025.02', tags: ['清邁','寺廟','古城'], color: 'linear-gradient(135deg,#D4A870,#8C6830)', url: '#' },
    { title: '曼谷 Michelin 街頭美食指南 2025', source: 'Wongnai · 2025.03', tags: ['曼谷','美食','Michelin'], color: 'linear-gradient(135deg,#C8907A,#885040)', url: '#' },
  ],
  IT: [
    { title: '羅馬 3 天行程：競技場到梵蒂岡', source: 'Italia.it · 2025.02', tags: ['羅馬','梵蒂岡','3天'], color: 'linear-gradient(135deg,#D4B890,#8C7840)', url: '#' },
    { title: '阿馬爾菲海岸公路旅行完整指南', source: 'Lonely Planet · 2025.01', tags: ['阿馬爾菲','海岸','自駕'], color: 'linear-gradient(135deg,#78A8C4,#305878)', url: '#' },
  ],
  FR: [
    { title: '巴黎時尚週期間，最值得一去的 10 間餐廳', source: 'Le Fooding · 2025.03', tags: ['巴黎','餐廳','時尚'], color: 'linear-gradient(135deg,#B898C8,#685880)', url: '#' },
    { title: '普羅旺斯薰衣草花季時程 × 拍照秘境', source: 'FranceTourisme · 2025.02', tags: ['普羅旺斯','薰衣草'], color: 'linear-gradient(135deg,#9890C8,#485088)', url: '#' },
  ],
  GB: [
    { title: '愛丁堡古堡 × 蘇格蘭高地 5 天行程', source: 'VisitScotland · 2025.02', tags: ['愛丁堡','蘇格蘭','高地'], color: 'linear-gradient(135deg,#88A0B8,#385060)', url: '#' },
  ],
  US: [
    { title: '紐約 7 天行程：曼哈頓到布魯克林', source: 'NYT Travel · 2025.03', tags: ['紐約','曼哈頓'], color: 'linear-gradient(135deg,#C8B8A0,#887850)', url: '#' },
  ],
  VN: [
    { title: '河內 × 下龍灣 5 天深度旅遊指南', source: 'VN Discovery · 2025.02', tags: ['河內','下龍灣'], color: 'linear-gradient(135deg,#90C0A0,#408050)', url: '#' },
  ],
  SG: [
    { title: '新加坡必吃 hawker centre 美食地圖', source: 'HungryGoWhere · 2025.03', tags: ['新加坡','美食','小販中心'], color: 'linear-gradient(135deg,#C0A090,#806040)', url: '#' },
  ],
};

Views = window.Views || {};
Views.Recommend = (() => {
  let activeCountry = 'JP';

  function renderChips() {
    const wrap = document.getElementById('rec-country-filter');
    wrap.innerHTML = COUNTRIES.map(c =>
      `<div class="country-chip ${c.code === activeCountry ? 'active' : ''}" data-code="${c.code}">${c.flag} ${c.name}</div>`
    ).join('');
    wrap.querySelectorAll('.country-chip').forEach(el => {
      el.addEventListener('click', () => {
        activeCountry = el.dataset.code;
        renderChips();
        renderCards();
      });
    });
  }

  function renderCards() {
    const list = document.getElementById('rec-card-list');
    const articles = SAMPLE_ARTICLES[activeCountry] || [];
    if (!articles.length) {
      list.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🔍</div><div class="empty-state-text">尚無內容</div><div class="empty-state-sub">持續更新中，敬請期待</div></div>`;
      return;
    }
    list.innerHTML = articles.map(a => `
      <div class="rec-card" onclick="window.open('${a.url}','_blank')">
        <div class="rec-thumb" style="background:${a.color}"></div>
        <div class="rec-info">
          <div class="rec-source">${a.source}</div>
          <div class="rec-title">${a.title}</div>
          <div class="rec-tags">${a.tags.map(t => `<span class="rec-tag">${t}</span>`).join('')}</div>
        </div>
      </div>
    `).join('');
  }

  function init() {
    renderChips();
    renderCards();
  }

  return { init };
})();
