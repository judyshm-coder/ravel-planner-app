// ── Views.Editor ─────────────────────────────────────────────────
Views = window.Views || {};
Views.Editor = (() => {
  let tripId = null;
  let activeDayId = null;
  let dragSrcId = null;

  function init(params) {
    tripId = params.tripId;
    if (!tripId) return;
    const trip = DB.getTrip(tripId);
    if (!trip) return;

    // Header
    document.getElementById('editor-trip-name').textContent = trip.name;
    const s = trip.startDate ? new Date(trip.startDate).toLocaleDateString('zh-TW', { month: 'long', day: 'numeric' }) : '';
    const e = trip.endDate   ? new Date(trip.endDate).toLocaleDateString('zh-TW',   { month: 'long', day: 'numeric' }) : '';
    const days = DB.getDays(tripId);
    document.getElementById('editor-trip-meta').textContent = `${s}${s && e ? ' — ' : ''}${e}  ·  ${days.length} 天 ${days.length > 0 ? days.length - 1 : 0} 夜`;

    // Back btn
    document.getElementById('editor-back').onclick = () => {
      App.navigate('trips');
    };

    // Export buttons
    document.getElementById('editor-export-json').onclick = exportJSON;
    document.getElementById('editor-export-ics').onclick = exportICS;

    // Render day tabs
    activeDayId = days.length ? days[0].id : null;
    renderDayTabs();
  }

  function renderDayTabs() {
    const days = DB.getDays(tripId);
    const wrap = document.getElementById('editor-day-tabs');
    wrap.innerHTML = days.map(d => `
      <div class="day-tab ${d.id === activeDayId ? 'active' : ''}" data-id="${d.id}">
        Day ${d.dayNumber}
        <span style="font-size:9px;color:inherit;opacity:.75;display:block;text-align:center">${formatShortDate(d.date)}</span>
      </div>`).join('') +
      `<div class="day-tab add-day" id="add-day-btn">＋ 天</div>`;

    wrap.querySelectorAll('.day-tab:not(.add-day)').forEach(el => {
      el.addEventListener('click', () => {
        activeDayId = el.dataset.id;
        renderDayTabs();
        renderTimeline();
      });
    });
    document.getElementById('add-day-btn').onclick = addDay;
    renderTimeline();
  }

  function renderTimeline() {
    const tl = document.getElementById('editor-timeline');
    const events = DB.getEventsByDay(tripId, activeDayId);
    const transports = DB.getTransports(tripId);
    tl.innerHTML = '';

    if (!events.length) {
      tl.innerHTML = `<div style="text-align:center;padding:40px 0 20px;color:var(--ink3)">
        <div style="font-size:36px;margin-bottom:12px">🗺️</div>
        <div style="font-family:'DM Serif Display',serif;font-size:18px;color:var(--ink2);margin-bottom:6px">今天還沒有行程</div>
        <div style="font-size:13px">點擊下方「新增行程」開始規劃</div>
      </div>`;
    } else {
      events.forEach((ev, i) => {
        // Conflict check
        const conflicts = DB.checkConflict(tripId, activeDayId, ev.startTime, ev.endTime, ev.id);
        if (conflicts.length) {
          tl.innerHTML += `<div class="conflict-warning">⚠ 時間衝突：${ev.title} 與 ${conflicts.map(c => c.title).join('、')} 時段重疊</div>`;
        }
        tl.innerHTML += buildEventNode(ev, i === events.length - 1);

        // Transport between events
        if (i < events.length - 1) {
          const tr = transports.find(t => t.fromEventId === ev.id);
          tl.innerHTML += buildTransportNode(ev.id, tr);
        }
      });
    }

    // Add event row
    tl.innerHTML += `
      <div class="add-ev-row">
        <button class="add-ev-btn" id="add-ev-btn">
          <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M6.5 1.5v10M1.5 6.5h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
          新增行程
        </button>
      </div>`;
    document.getElementById('add-ev-btn').onclick = () => openEventDetail(null);

    // Bind event cards
    tl.querySelectorAll('[data-ev-id]').forEach(el => {
      const evId = el.dataset.evId;
      el.querySelector('.ev-edit-btn')?.addEventListener('click', () => openEventDetail(evId));
      el.querySelector('.ev-map-btn')?.addEventListener('click', () => openMaps(evId));
      el.querySelector('.ev-del-btn')?.addEventListener('click', () => deleteEvent(evId));
    });

    // Transport badges
    tl.querySelectorAll('[data-tr-from]').forEach(el => {
      el.addEventListener('click', () => openTransportPicker(el.dataset.trFrom));
    });

    // Drag & drop
    bindDragDrop();
  }

  function buildEventNode(ev, isLast) {
    const img = ev.images && ev.images.length
      ? `<div class="ev-thumb" style="background-image:url('${ev.images[0]}')"></div>`
      : ev.category === 'restaurant' ? `<div class="ev-thumb" style="background:linear-gradient(135deg,#D4B8A8,#A08070)"></div>`
      : `<div class="ev-thumb" style="background:linear-gradient(135deg,#D4C4A8,#A08858)"></div>`;

    const timeStr = ev.startTime ? ev.startTime + (ev.endTime ? '–' + ev.endTime : '') : '';
    const addrStr = ev.address ? `<span class="ev-meta-item">${App.Icons.pin} ${ev.address.slice(0, 20)}${ev.address.length > 20 ? '…' : ''}</span>` : '';

    return `
      <div class="tl-item" data-ev-id="${ev.id}" draggable="true">
        <div class="tl-time-col"><span class="tl-time">${ev.startTime || ''}</span></div>
        <div class="tl-spine-col">
          <div class="tl-dot ${ev.startTime ? 'filled' : ''}"></div>
          ${!isLast ? '<div class="tl-line"></div>' : ''}
        </div>
        <div class="tl-content-col">
          <div class="ev-card">
            ${img}
            <div class="ev-body">
              <div class="ev-category ${App.categoryClass(ev.category)}">${App.categoryLabel(ev.category)}</div>
              <div class="ev-title-text">${ev.title || '（未命名行程）'}</div>
              <div class="ev-meta-row">
                ${timeStr ? `<span class="ev-meta-item">${App.Icons.clock} ${timeStr}</span>` : ''}
                ${addrStr}
              </div>
            </div>
            <div class="ev-actions">
              <button class="ev-action-btn ev-edit-btn">編輯</button>
              <button class="ev-action-btn ev-map-btn">地圖</button>
              ${ev.links && ev.links.length ? `<button class="ev-action-btn" onclick="window.open('${ev.links[0].url}','_blank')">連結</button>` : ''}
              <button class="ev-action-btn ev-del-btn" style="margin-left:auto;color:var(--rose)">刪除</button>
            </div>
            <div class="ev-drag-handle" data-drag="${ev.id}">
              <div class="drag-bar"></div><div class="drag-bar"></div>
            </div>
          </div>
        </div>
      </div>`;
  }

  function buildTransportNode(fromEventId, tr) {
    const hasTransport = tr && tr.mode;
    const label = hasTransport ? App.transportLabel(tr.mode) : '＋ 設定交通';
    const cls = hasTransport ? App.transportClass(tr.mode) : 'tb-unset';
    const dur = hasTransport && tr.durationMin ? `${tr.durationMin} 分` : '';
    const cost = hasTransport && tr.cost ? ` · ¥${tr.cost}` : '';
    const modeIcon = hasTransport ? transportModeIcon(tr.mode) : '';
    return `
      <div class="tl-item" style="align-items:center">
        <div class="tl-time-col"></div>
        <div class="tl-spine-col">
          <div style="width:8px;height:8px;border-radius:50%;background:var(--cream3);border:1.5px solid var(--cream4);flex-shrink:0"></div>
          <div class="tl-line" style="min-height:24px"></div>
        </div>
        <div class="tl-content-col" style="padding-bottom:0">
          <div class="transport-node">
            <div class="transport-badge ${cls}" data-tr-from="${fromEventId}">
              ${modeIcon}${label}
            </div>
            ${dur ? `<span class="transport-dur">${dur}${cost}</span>` : ''}
          </div>
        </div>
      </div>`;
  }

  function transportModeIcon(mode) {
    const icons = {
      walk:  `<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><circle cx="5.5" cy="5.5" r="4.5" stroke="currentColor" stroke-width="1"/><path d="M5.5 3.5v3M5.5 8v.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
      rail:  `<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><rect x="1.5" y="3.5" width="8" height="4.5" rx="1.5" stroke="currentColor" stroke-width="1"/><path d="M3.5 3.5V3a1 1 0 011-1h2a1 1 0 011 1v.5" stroke="currentColor" stroke-width="1"/><circle cx="3.5" cy="7.5" r=".8" fill="currentColor"/><circle cx="7.5" cy="7.5" r=".8" fill="currentColor"/></svg>`,
      bus:   `<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><rect x="1.5" y="4" width="8" height="4" rx="1.5" stroke="currentColor" stroke-width="1"/><path d="M4 4V3.5a1 1 0 011-1h1a1 1 0 011 1V4" stroke="currentColor" stroke-width="1"/><circle cx="3" cy="7.5" r=".8" fill="currentColor"/><circle cx="8" cy="7.5" r=".8" fill="currentColor"/></svg>`,
      air:   `<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M1.5 8l4-6 4 6" stroke="currentColor" stroke-width="1" stroke-linecap="round"/><path d="M.5 8h10" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
      ferry: `<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M1.5 7c0-1.5 1-3 3-3h2c2 0 3 1.5 3 3v.5H1.5V7z" stroke="currentColor" stroke-width="1"/><path d="M4 4V2.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
      taxi:  `<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><rect x="1" y="4.5" width="9" height="4" rx="1.5" stroke="currentColor" stroke-width="1"/><path d="M3.5 4.5V3.5a.5.5 0 01.5-.5h3a.5.5 0 01.5.5v1" stroke="currentColor" stroke-width="1"/><circle cx="3" cy="8" r=".8" fill="currentColor"/><circle cx="8" cy="8" r=".8" fill="currentColor"/></svg>`,
    };
    return (icons[mode] || '') + ' ';
  }

  // ── Drag & Drop ──────────────────────────────────────────────
  function bindDragDrop() {
    const items = document.querySelectorAll('[data-ev-id]');
    items.forEach(el => {
      el.addEventListener('dragstart', e => {
        dragSrcId = el.dataset.evId;
        setTimeout(() => el.querySelector('.ev-card').classList.add('dragging'), 0);
        e.dataTransfer.effectAllowed = 'move';
      });
      el.addEventListener('dragend', () => {
        document.querySelectorAll('.ev-card').forEach(c => c.classList.remove('dragging', 'drag-over'));
      });
      el.addEventListener('dragover', e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        el.querySelector('.ev-card').classList.add('drag-over');
      });
      el.addEventListener('dragleave', () => el.querySelector('.ev-card').classList.remove('drag-over'));
      el.addEventListener('drop', e => {
        e.preventDefault();
        if (dragSrcId && dragSrcId !== el.dataset.evId) {
          const orderedIds = [...document.querySelectorAll('[data-ev-id]')].map(n => n.dataset.evId);
          const srcIdx = orderedIds.indexOf(dragSrcId);
          const dstIdx = orderedIds.indexOf(el.dataset.evId);
          orderedIds.splice(srcIdx, 1);
          orderedIds.splice(dstIdx, 0, dragSrcId);
          DB.reorderEvents(tripId, activeDayId, orderedIds);
          renderTimeline();
        }
      });
    });

    // Touch drag
    items.forEach(el => {
      const handle = el.querySelector('.ev-drag-handle');
      if (!handle) return;
      let startY, clone;
      handle.addEventListener('touchstart', e => {
        startY = e.touches[0].clientY;
        dragSrcId = el.dataset.evId;
        clone = el.cloneNode(true);
        clone.style.cssText = `position:fixed;width:${el.offsetWidth}px;opacity:.8;pointer-events:none;z-index:9999;left:${el.getBoundingClientRect().left}px;top:${el.getBoundingClientRect().top}px;`;
        document.body.appendChild(clone);
        el.querySelector('.ev-card').classList.add('dragging');
      }, { passive: true });
      handle.addEventListener('touchmove', e => {
        e.preventDefault();
        const dy = e.touches[0].clientY - startY;
        if (clone) clone.style.top = (parseInt(clone.style.top) + dy) + 'px';
        startY = e.touches[0].clientY;
        const target = document.elementFromPoint(e.touches[0].clientX, e.touches[0].clientY)?.closest('[data-ev-id]');
        document.querySelectorAll('.ev-card').forEach(c => c.classList.remove('drag-over'));
        if (target && target !== el) target.querySelector('.ev-card').classList.add('drag-over');
      }, { passive: false });
      handle.addEventListener('touchend', e => {
        if (clone) { clone.remove(); clone = null; }
        el.querySelector('.ev-card').classList.remove('dragging');
        const target = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY)?.closest('[data-ev-id]');
        if (target && target !== el) {
          const orderedIds = [...document.querySelectorAll('[data-ev-id]')].map(n => n.dataset.evId);
          const srcIdx = orderedIds.indexOf(dragSrcId);
          const dstIdx = orderedIds.indexOf(target.dataset.evId);
          if (srcIdx !== -1 && dstIdx !== -1) {
            orderedIds.splice(srcIdx, 1);
            orderedIds.splice(dstIdx, 0, dragSrcId);
            DB.reorderEvents(tripId, activeDayId, orderedIds);
          }
        }
        document.querySelectorAll('.ev-card').forEach(c => c.classList.remove('drag-over'));
        renderTimeline();
      });
    });
  }

  // ── Actions ──────────────────────────────────────────────────
  function openEventDetail(evId) {
    Views.EventDetail.open(tripId, activeDayId, evId, () => renderTimeline());
  }
  function openTransportPicker(fromEventId) {
    Views.TransportPicker.open(tripId, fromEventId, () => renderTimeline());
  }
  function openMaps(evId) {
    const ev = DB.getEvents(tripId).find(e => e.id === evId);
    if (!ev) return;
    const q = ev.googleMapsUrl || (ev.address ? `https://maps.google.com/?q=${encodeURIComponent(ev.address)}` : null);
    if (q) window.open(q, '_blank');
    else App.toast('尚未設定地址');
  }
  function deleteEvent(evId) {
    if (!confirm('確定刪除此行程？')) return;
    DB.deleteEvent(tripId, evId);
    renderTimeline();
    App.toast('行程已刪除');
  }
  function addDay() {
    const days = DB.getDays(tripId);
    const trip = DB.getTrip(tripId);
    // Add one day to endDate
    const newEnd = new Date(trip.endDate);
    newEnd.setDate(newEnd.getDate() + 1);
    const newEndStr = newEnd.toISOString().slice(0, 10);
    DB.updateTrip(tripId, { endDate: newEndStr });
    // Re-scaffold days
    const newDays = [];
    let cur = new Date(trip.startDate);
    let i = 1;
    while (cur <= newEnd) {
      const existing = days.find(d => d.date === cur.toISOString().slice(0, 10));
      newDays.push(existing || { id: DB.uid(), tripId, date: cur.toISOString().slice(0, 10), dayNumber: i, note: '' });
      cur.setDate(cur.getDate() + 1);
      i++;
    }
    newDays.forEach((d, idx) => d.dayNumber = idx + 1);
    localStorage.setItem('wp_tp:' + tripId + ':days', JSON.stringify(newDays));
    activeDayId = newDays[newDays.length - 1].id;
    renderDayTabs();
    App.toast('已新增第 ' + newDays.length + ' 天');
  }

  // ── Export ───────────────────────────────────────────────────
  function exportJSON() {
    const data = DB.exportTrip(tripId);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wanderplan-${DB.getTrip(tripId).name}-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    App.toast('JSON 匯出成功');
  }
  function exportICS() {
    const ics = DB.generateICS(tripId);
    const blob = new Blob([ics], { type: 'text/calendar' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wanderplan-${DB.getTrip(tripId).name}.ics`;
    a.click();
    URL.revokeObjectURL(url);
    App.toast('行事曆匯出成功（.ics）');
  }

  function formatShortDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return `${d.getMonth()+1}/${d.getDate()}`;
  }

  return { init };
})();
