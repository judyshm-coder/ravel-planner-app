// ── Views.Trips ──────────────────────────────────────────────────
Views = window.Views || {};

Views.Trips = (() => {
  function init() { render(); }

  function render() {
    const list = document.getElementById('trips-list');
    const trips = DB.getIndex();
    if (!trips.length) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">✈️</div>
          <div class="empty-state-text">還沒有旅行計畫</div>
          <div class="empty-state-sub">點擊下方「新增」建立你的第一個旅行計畫吧！</div>
        </div>`;
      return;
    }
    list.innerHTML = trips.map(t => tripCard(t)).join('');
    list.querySelectorAll('.trip-card').forEach(el => {
      el.addEventListener('click', () => App.navigate('editor', { tripId: el.dataset.id }));
    });
  }

  function tripCard(t) {
    const days = DB.getDays(t.id);
    const total = days.length;
    const events = DB.getEvents(t.id);
    const daysWithEvents = new Set(events.map(e => e.dayId)).size;
    const pct = total > 0 ? Math.round((daysWithEvents / total) * 100) : 0;

    // Cover: up to 3 images from events, fallback to colour ramps
    const imgs = events.filter(e => e.images && e.images.length).slice(0, 3).map(e => e.images[0]);
    const FALLBACKS = [
      'linear-gradient(135deg,#D4956A,#8C5E3A)',
      'linear-gradient(160deg,#B8A890,#8C7060)',
      'linear-gradient(135deg,#C8B89C,#907860)',
    ];
    const slots = [0, 1, 2].map(i => imgs[i]
      ? `<div class="trip-cover-img" style="background-image:url('${imgs[i]}')"></div>`
      : `<div class="trip-cover-img" style="background:${FALLBACKS[i]}"></div>`
    ).join('');

    const startStr = t.startDate ? new Date(t.startDate).toLocaleDateString('zh-TW', { month: 'short', day: 'numeric' }) : '';
    const endStr   = t.endDate   ? new Date(t.endDate).toLocaleDateString('zh-TW', { month: 'short', day: 'numeric' }) : '';
    const destStr  = t.destinations && t.destinations.length ? t.destinations.map(d => {
      const c = COUNTRIES.find(c => c.code === d);
      return c ? c.flag : d;
    }).join(' ') : '';

    return `
      <div class="trip-card" data-id="${t.id}">
        <div class="trip-cover">
          ${slots}
          <div class="trip-cover-overlay"></div>
          <div class="trip-cover-text">
            <div class="trip-cover-name">${destStr} ${t.name}</div>
            <div class="trip-cover-date">${startStr}${startStr && endStr ? ' – ' : ''}${endStr}${total ? ' · ' + total + '天' : ''}</div>
          </div>
        </div>
        <div class="trip-footer">
          <span class="trip-days-label">${daysWithEvents}/${total} 天規劃</span>
          <div class="trip-progress-bar"><div class="trip-progress-fill" style="width:${pct}%"></div></div>
          ${App.Icons.arrow}
        </div>
      </div>`;
  }

  return { init, render };
})();


// ── Views.AddPlan ─────────────────────────────────────────────────
Views.AddPlan = (() => {
  let selectedDests = [];
  let coverDataURL = null;

  function init() {
    selectedDests = [];
    coverDataURL = null;
    resetForm();
    bindEvents();
  }

  function resetForm() {
    document.getElementById('ap-name').value = '';
    document.getElementById('ap-start').value = '';
    document.getElementById('ap-end').value = '';
    coverDataURL = null;
    document.getElementById('ap-cover-preview').style.backgroundImage = '';
    document.getElementById('ap-cover-preview').innerHTML = `<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 4v12M4 10h12" stroke="#C4A882" stroke-width="1.8" stroke-linecap="round"/></svg><span style="font-size:10px;color:var(--ink3)">上傳</span>`;
    renderDestTags();
    renderDestGrid('');
  }

  function bindEvents() {
    // Dest control toggle
    const ctrl = document.getElementById('ap-dest-control');
    const dd = document.getElementById('ap-dest-dropdown');
    ctrl.onclick = () => {
      ctrl.classList.toggle('open');
      dd.classList.toggle('open');
    };

    // Dest search
    document.getElementById('ap-dest-search').oninput = e => renderDestGrid(e.target.value.trim());

    // Cover upload
    document.getElementById('ap-cover-input').onchange = async e => {
      const file = e.target.files[0];
      if (!file) return;
      coverDataURL = await App.readFileAsDataURL(file);
      const prev = document.getElementById('ap-cover-preview');
      prev.style.backgroundImage = `url('${coverDataURL}')`;
      prev.style.backgroundSize = 'cover';
      prev.style.backgroundPosition = 'center';
      prev.innerHTML = '';
    };

    // Submit
    document.getElementById('ap-submit').onclick = submit;
  }

  function renderDestTags() {
    const ctrl = document.getElementById('ap-dest-control');
    const placeholder = selectedDests.length === 0
      ? `<span class="dest-placeholder">選擇目的地（可複選）</span>`
      : '';
    const tags = selectedDests.map(code => {
      const c = COUNTRIES.find(c => c.code === code);
      return `<span class="dest-tag-pill" data-code="${code}">${c ? c.flag + ' ' + c.name : code}<span class="remove" data-code="${code}">×</span></span>`;
    }).join('');
    ctrl.innerHTML = tags + placeholder + `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 5l4 4 4-4" stroke="#9E8270" stroke-width="1.3" stroke-linecap="round"/></svg>`;
    ctrl.querySelectorAll('.remove').forEach(el => {
      el.onclick = e => {
        e.stopPropagation();
        selectedDests = selectedDests.filter(d => d !== el.dataset.code);
        renderDestTags();
        renderDestGrid('');
      };
    });
  }

  function renderDestGrid(query) {
    const grid = document.getElementById('ap-dest-grid');
    const filtered = query
      ? COUNTRIES.filter(c => c.name.includes(query) || c.code.toLowerCase().includes(query.toLowerCase()))
      : COUNTRIES;
    grid.innerHTML = filtered.map(c => `
      <div class="dest-option ${selectedDests.includes(c.code) ? 'selected' : ''}" data-code="${c.code}">
        <span class="dest-flag">${c.flag}</span>
        <span class="dest-name">${c.name}</span>
      </div>`).join('');
    grid.querySelectorAll('.dest-option').forEach(el => {
      el.onclick = () => {
        const code = el.dataset.code;
        if (selectedDests.includes(code)) {
          selectedDests = selectedDests.filter(d => d !== code);
        } else {
          selectedDests.push(code);
        }
        renderDestTags();
        renderDestGrid(document.getElementById('ap-dest-search').value);
      };
    });
  }

  async function submit() {
    const name = document.getElementById('ap-name').value.trim();
    const start = document.getElementById('ap-start').value;
    const end = document.getElementById('ap-end').value;
    if (!name) { App.toast('請輸入計畫名稱'); return; }
    if (!start || !end) { App.toast('請選擇旅行日期'); return; }
    if (new Date(end) < new Date(start)) { App.toast('回程不能早於出發日'); return; }

    const trip = DB.createTrip({ name, startDate: start, endDate: end, destinations: selectedDests, coverImage: coverDataURL });
    App.closeModal('modal-add-plan');
    App.toast('計畫建立成功 ✓');
    Views.Trips.render();
    setTimeout(() => App.navigate('editor', { tripId: trip.id }), 300);
  }

  return { init };
})();
